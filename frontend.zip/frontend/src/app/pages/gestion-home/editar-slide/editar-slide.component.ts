import { Component, Input, Output, EventEmitter } from '@angular/core';

import { FormsModule } from '@angular/forms';
import { CarouselSlide } from '../home-dashboard/home-dashboard.component';

@Component({
  selector: 'app-editar-slide',
  standalone: true,
  imports: [FormsModule],
  templateUrl: './editar-slide.component.html',
  styleUrls: ['./editar-slide.component.css']
})
export class EditarSlideComponent {
  @Input() slide: CarouselSlide | null = null;
  @Output() guardar = new EventEmitter<CarouselSlide>();
  @Output() cancelar = new EventEmitter<void>();

  slideEditado: CarouselSlide = {
    id: 0,
    image: '',
    title: '',
    subtitle: ''
  };

  ngOnChanges() {
    if (this.slide) {
      this.slideEditado = { ...this.slide };
    }
  }

  onGuardar() {
    this.guardar.emit(this.slideEditado);
  }

  onCancelar() {
    this.cancelar.emit();
  }
}
